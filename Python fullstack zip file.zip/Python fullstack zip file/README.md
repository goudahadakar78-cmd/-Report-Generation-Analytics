# Report Generation & Analytics Tool

Internship Task: PY-AT-005 | Flask + MySQL

## Features
- User registration, login and logout with hashed passwords
- Dashboard with report metrics and Chart.js visualization
- Report builder with date/status filters
- PDF, Excel, CSV and JSON exports
- Report export history and downloads
- Schedule creation and management (schedule records are stored in MySQL)
- Email delivery of generated report files
- Celery task and async-generation route for background report generation

## 1. Requirements
- Python 3.10+
- MySQL Server 8+
- Git
- Optional for background tasks: Redis

## 2. Create the database
Log in to MySQL and run:

```sql
CREATE DATABASE report_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'report_user'@'localhost' IDENTIFIED BY 'ChooseYourOwnPassword';
GRANT ALL PRIVILEGES ON report_db.* TO 'report_user'@'localhost';
FLUSH PRIVILEGES;
```

Use your own strong database password. Do not commit credentials.

## 3. Install
Windows PowerShell:

```powershell
mkdir report_analytics
cd report_analytics
python -m venv venv
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
```

Edit `.env` and set SECRET_KEY, DATABASE_URL and email settings.

If PowerShell blocks activation, run `venv\Scripts\activate.bat` from Command Prompt, or use `python -m pip install -r requirements.txt` with the venv's Python.

## 4. Initialize tables and demo data
```powershell
flask --app run.py init-db
flask --app run.py seed-demo
```

## 5. Start the web app
```powershell
python run.py
```
Open http://127.0.0.1:5000

Demo login after seeding:
- Email: demo@example.com
- Password: DemoPass123!
Change or remove this demo account before any public deployment.

## 6. Celery worker (optional)
Start Redis first, then in another terminal:

```powershell
celery -A celery_worker.celery worker --loglevel=info --pool=solo
```

The project includes a Celery task and `/reports/<id>/generate-async` endpoint. Create a pending report record, then POST to that endpoint while logged in; Redis and a running Celery worker are required. The standard report builder also generates files synchronously without Redis.

## 7. Email
For Gmail, use an App Password where available, not your normal account password. Configure MAIL_* values in `.env`. Email delivery is initiated from a generated report's history page.

## 8. GitHub
```powershell
git init
git add .
git commit -m "Build report generation and analytics tool"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/report-generation-analytics.git
git push -u origin main
```

## 9. Before submission
- Run the app and verify registration/login.
- Verify each export format and open the downloaded files.
- Test report filters and dashboard charts.
- Configure and test email delivery only with an account you control.
- Verify schedule records are saved and displayed. This starter stores schedule definitions; automatic recurring execution requires a running scheduler/worker and must be configured for the deployment environment.
- Take genuine screenshots and record a short demo of the working application.
- Deploy only after setting production secrets, HTTPS, database access and debug=False.

## Project structure
```text
report_analytics/
  app/
    __init__.py
    models.py
    routes.py
    reports.py
    tasks.py
    templates/
    static/
  exports/
  .env.example
  requirements.txt
  run.py
  celery_worker.py
```

Never upload `.env`, passwords, email app passwords or private keys to GitHub.
