import csv, io, json, os
from datetime import datetime
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from openpyxl import Workbook

HEADERS = ["id", "name", "format", "status", "created_at", "generated_at"]

def report_rows(reports):
    return [[r.id, r.name, r.format, r.status,
             r.created_at.strftime("%Y-%m-%d %H:%M") if r.created_at else "",
             r.generated_at.strftime("%Y-%m-%d %H:%M") if r.generated_at else ""]
            for r in reports]

def create_export(reports, fmt, folder, report_id):
    rows = report_rows(reports)
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, f"report_{report_id}_{datetime.utcnow():%Y%m%d%H%M%S}.{fmt}")
    if fmt == "csv":
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f); writer.writerow(HEADERS); writer.writerows(rows)
    elif fmt == "json":
        data = [dict(zip(HEADERS, row)) for row in rows]
        with open(path, "w", encoding="utf-8") as f: json.dump(data, f, indent=2)
    elif fmt == "excel":
        wb = Workbook(); ws = wb.active; ws.title = "Reports"
        ws.append(HEADERS)
        for row in rows: ws.append(row)
        wb.save(path)
    elif fmt == "pdf":
        c = canvas.Canvas(path, pagesize=letter)
        width, height = letter
        c.setFont("Helvetica-Bold", 16); c.drawString(45, height-50, "Report Generation & Analytics")
        c.setFont("Helvetica", 8); y = height-85
        c.drawString(45, y, " | ".join(HEADERS)); y -= 20
        for row in rows:
            if y < 50: c.showPage(); y = height-50
            c.drawString(45, y, " | ".join(str(x)[:28] for x in row)); y -= 16
        c.save()
    else:
        raise ValueError("Unsupported format")
    return path
