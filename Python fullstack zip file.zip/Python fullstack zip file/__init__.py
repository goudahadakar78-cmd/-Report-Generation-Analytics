import os
import click
from dotenv import load_dotenv
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_bcrypt import Bcrypt
from flask_mail import Mail
from celery import Celery

load_dotenv()
db = SQLAlchemy()
login_manager = LoginManager()
bcrypt = Bcrypt()
mail = Mail()
celery = Celery(__name__)

def create_app():
    app = Flask(__name__)
    app.config.update(
        SECRET_KEY=os.getenv("SECRET_KEY", "dev-only-change-me"),
        SQLALCHEMY_DATABASE_URI=os.getenv("DATABASE_URL", "sqlite:///report_dev.db"),
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
        MAIL_SERVER=os.getenv("MAIL_SERVER"),
        MAIL_PORT=int(os.getenv("MAIL_PORT", "587")),
        MAIL_USE_TLS=os.getenv("MAIL_USE_TLS", "True").lower() == "true",
        MAIL_USERNAME=os.getenv("MAIL_USERNAME"),
        MAIL_PASSWORD=os.getenv("MAIL_PASSWORD"),
        MAIL_DEFAULT_SENDER=os.getenv("MAIL_DEFAULT_SENDER"),
        REDIS_URL=os.getenv("REDIS_URL", "redis://localhost:6379/0"),
        EXPORT_FOLDER=os.path.join(app.root_path, "..", "exports"),
        MAX_CONTENT_LENGTH=10 * 1024 * 1024,
    )
    os.makedirs(app.config["EXPORT_FOLDER"], exist_ok=True)
    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = "main.login"
    bcrypt.init_app(app)
    mail.init_app(app)

    from . import models
    from .routes import bp
    app.register_blueprint(bp)

    @app.cli.command("init-db")
    def init_db():
        db.create_all()
        click.echo("Database tables created.")

    @app.cli.command("seed-demo")
    def seed_demo():
        from .models import User, Report
        db.create_all()
        if not User.query.filter_by(email="demo@example.com").first():
            user = User(username="Demo Student", email="demo@example.com",
                        password=bcrypt.generate_password_hash("DemoPass123!").decode())
            db.session.add(user)
            db.session.flush()
            for i, (name, status, fmt) in enumerate([
                ("Monthly Sales", "completed", "pdf"),
                ("Student Attendance", "completed", "excel"),
                ("Inventory Summary", "pending", "csv"),
            ]):
                db.session.add(Report(name=name, status=status, format=fmt,
                                      generated_by=user.id if status == "completed" else None))
            db.session.commit()
        click.echo("Demo data ready. demo@example.com / DemoPass123!")

    return app
