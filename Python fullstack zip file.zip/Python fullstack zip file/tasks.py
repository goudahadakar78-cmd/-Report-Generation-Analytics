from . import celery, db
from .models import Report
from .reports import create_export

@celery.task(name="app.tasks.generate_report")
def generate_report(report_id, user_id, fmt, export_folder):
    report = db.session.get(Report, report_id)
    if report is None:
        return {"ok": False, "message": "Report not found"}
    try:
        report.status = "generating"
        db.session.commit()
        path = create_export(Report.query.filter_by(generated_by=user_id).all(), fmt, export_folder, report_id)
        report.file_path = path
        report.file_size = __import__("os").path.getsize(path)
        report.format = fmt
        report.status = "completed"
        from datetime import datetime
        report.generated_at = datetime.utcnow()
        db.session.commit()
        return {"ok": True, "path": path}
    except Exception as exc:
        report.status = "failed"
        db.session.commit()
        raise exc
