import os, json
from datetime import datetime
from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app, send_file, abort
from flask_login import login_user, logout_user, login_required, current_user
from flask_mail import Message
from . import db, bcrypt, mail, celery
from .models import User, Report, ReportSchedule, ReportLog
from .reports import create_export

bp = Blueprint("main", __name__)

@bp.route("/")
@login_required
def dashboard():
    reports = Report.query.filter_by(generated_by=current_user.id).order_by(Report.created_at.desc()).all()
    completed = sum(r.status == "completed" for r in reports)
    pending = sum(r.status == "pending" for r in reports)
    return render_template("dashboard.html", reports=reports[:8], total=len(reports),
                           completed=completed, pending=pending,
                           chart_labels=json.dumps(["Completed", "Pending", "Failed"]),
                           chart_values=json.dumps([sum(r.status=="completed" for r in reports),
                                                    pending, sum(r.status=="failed" for r in reports)]))

@bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username, email, password = request.form.get("username","").strip(), request.form.get("email","").strip().lower(), request.form.get("password","")
        if not username or not email or len(password) < 8:
            flash("Enter a name, valid email and password with at least 8 characters.", "danger")
        elif User.query.filter_by(email=email).first():
            flash("That email is already registered.", "warning")
        else:
            user = User(username=username, email=email, password=bcrypt.generate_password_hash(password).decode())
            db.session.add(user); db.session.commit()
            login_user(user); return redirect(url_for("main.dashboard"))
    return render_template("register.html")

@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        user = User.query.filter_by(email=request.form.get("email","").strip().lower()).first()
        if user and bcrypt.check_password_hash(user.password, request.form.get("password","")):
            login_user(user); return redirect(url_for("main.dashboard"))
        flash("Incorrect email or password.", "danger")
    return render_template("login.html")

@bp.route("/logout")
@login_required
def logout():
    logout_user(); return redirect(url_for("main.login"))

@bp.route("/reports")
@login_required
def reports():
    q = Report.query.filter_by(generated_by=current_user.id)
    status = request.args.get("status")
    if status in {"pending","generating","completed","failed"}: q = q.filter_by(status=status)
    return render_template("reports.html", reports=q.order_by(Report.created_at.desc()).all())

@bp.route("/reports/new", methods=["GET", "POST"])
@login_required
def new_report():
    if request.method == "POST":
        name = request.form.get("name","").strip()
        fmt = request.form.get("format","pdf")
        if not name or fmt not in {"pdf","excel","csv","json"}:
            flash("Enter a report name and choose a supported format.", "danger")
            return redirect(url_for("main.new_report"))
        report = Report(name=name, format=fmt, status="pending", generated_by=current_user.id,
                        filters_applied=json.dumps({"status": request.form.get("filter_status","all")}))
        db.session.add(report); db.session.commit()
        try:
            report.status = "generating"; db.session.commit()
            query = Report.query.filter_by(generated_by=current_user.id)
            selected = request.form.get("filter_status","all")
            if selected != "all": query = query.filter_by(status=selected)
            path = create_export(query.all(), fmt, current_app.config["EXPORT_FOLDER"], report.id)
            report.file_path = path; report.file_size = os.path.getsize(path)
            report.status = "completed"; report.generated_at = datetime.utcnow()
            db.session.add(ReportLog(report_id=report.id, status="completed", message="Report generated"))
            db.session.commit()
            flash("Report generated successfully.", "success")
        except Exception as exc:
            report.status = "failed"; db.session.commit()
            flash(f"Report generation failed: {exc}", "danger")
        return redirect(url_for("main.reports"))
    return render_template("report_builder.html")

@bp.route("/reports/<int:report_id>/download")
@login_required
def download_report(report_id):
    report = Report.query.filter_by(id=report_id, generated_by=current_user.id).first_or_404()
    if not report.file_path or not os.path.isfile(report.file_path): abort(404)
    report.download_count += 1; db.session.commit()
    return send_file(report.file_path, as_attachment=True)

@bp.route("/reports/<int:report_id>/email", methods=["POST"])
@login_required
def email_report(report_id):
    report = Report.query.filter_by(id=report_id, generated_by=current_user.id).first_or_404()
    recipient = request.form.get("recipient","").strip()
    if not recipient or not report.file_path or not os.path.isfile(report.file_path):
        flash("Provide a recipient and ensure the report file exists.", "danger")
    else:
        try:
            with open(report.file_path, "rb") as f: content = f.read()
            msg = Message(subject=f"Your report: {report.name}", recipients=[recipient],
                          body="Please find your generated report attached.")
            msg.attach(os.path.basename(report.file_path), "application/octet-stream", content)
            mail.send(msg); flash("Email sent.", "success")
        except Exception as exc: flash(f"Email could not be sent. Check MAIL settings: {exc}", "danger")
    return redirect(url_for("main.reports"))

@bp.route("/schedules", methods=["GET", "POST"])
@login_required
def schedules():
    if request.method == "POST":
        name = request.form.get("name","").strip()
        fmt = request.form.get("format","pdf"); freq = request.form.get("frequency","daily")
        if not name or fmt not in {"pdf","excel","csv","json"} or freq not in {"once","daily","weekly","monthly"}:
            flash("Check schedule details.", "danger")
        else:
            s = ReportSchedule(name=name, format=fmt, frequency=freq,
                time=request.form.get("time","09:00"),
                recipient_emails=request.form.get("recipient_emails","").strip(),
                created_by=current_user.id)
            db.session.add(s); db.session.commit()
            flash("Schedule definition saved. Automatic recurring execution needs a configured scheduler.", "success")
        return redirect(url_for("main.schedules"))
    items = ReportSchedule.query.filter_by(created_by=current_user.id).order_by(ReportSchedule.created_at.desc()).all()
    return render_template("schedules.html", schedules=items)

@bp.route("/schedules/<int:sid>/toggle", methods=["POST"])
@login_required
def toggle_schedule(sid):
    s = ReportSchedule.query.filter_by(id=sid, created_by=current_user.id).first_or_404()
    s.is_active = not s.is_active; db.session.commit()
    return redirect(url_for("main.schedules"))
